from __future__ import annotations
import os, math, time
from typing import Any
import requests
from flask import Flask, jsonify, request, render_template

app = Flask(__name__, static_folder="static", template_folder="templates")
TOMTOM_API_KEY = os.getenv("TOMTOM_API_KEY", "").strip()
TRAFFIC_MODE = os.getenv("TRAFFIC_MODE", "demo").lower()
DEFAULT_CENTER = {"lat": float(os.getenv("DEFAULT_LAT", "17.3850")),
                  "lon": float(os.getenv("DEFAULT_LON", "78.4867"))}  # Hyderabad demo center

# Demo data is intentionally labelled as simulated; it is never presented as live.
DEMO_SEGMENTS = [
    {"id":"market-road","name":"Market Road Junction","lat":17.3890,"lon":78.4810,"speed_kmh":9,"free_flow_kmh":40,"length_km":1.2,"vehicles":186,"incident":"Queue building"},
    {"id":"central-ring","name":"Central Ring Road","lat":17.3920,"lon":78.4920,"speed_kmh":13,"free_flow_kmh":50,"length_km":1.8,"vehicles":142,"incident":"Freight merge"},
    {"id":"east-avenue","name":"East Avenue","lat":17.3820,"lon":78.5050,"speed_kmh":28,"free_flow_kmh":40,"length_km":1.0,"vehicles":62,"incident":None},
    {"id":"south-link","name":"South Transit Link","lat":17.3700,"lon":78.4890,"speed_kmh":38,"free_flow_kmh":45,"length_km":1.5,"vehicles":34,"incident":None},
    {"id":"airport-road","name":"Airport Connector","lat":17.3600,"lon":78.4750,"speed_kmh":31,"free_flow_kmh":55,"length_km":2.0,"vehicles":71,"incident":None},
]

def congestion_level(speed: float, free_flow: float) -> tuple[str, int]:
    ratio = speed / max(free_flow, 1)
    score = round(max(0, min(100, (1 - ratio) * 100)))
    level = "high" if score >= 65 else "moderate" if score >= 35 else "low"
    return level, score

def demo_traffic() -> dict[str, Any]:
    now = int(time.time())
    segments = []
    for s in DEMO_SEGMENTS:
        level, score = congestion_level(s["speed_kmh"], s["free_flow_kmh"])
        segments.append({**s, "congestion_level":level, "congestion_score":score,
                         "delay_min":round(max(0, s["length_km"] / max(s["speed_kmh"], 5) * 60 -
                                                s["length_km"] / s["free_flow_kmh"] * 60), 1)})
    return {"source":"simulated_demo_data", "is_live":False, "updated_at":now,
            "center":DEFAULT_CENTER, "segments":segments}

def tomtom_traffic(lat: float, lon: float) -> dict[str, Any]:
    """Fetch one TomTom Traffic Flow segment near the requested point.
    TomTom API key is read only from the server environment, never sent to browser.
    """
    url = "https://api.tomtom.com/traffic/services/4/flowSegmentData/relative0/10/json"
    response = requests.get(url, params={"point":f"{lat},{lon}", "unit":"KMPH",
                                         "key":TOMTOM_API_KEY}, timeout=8)
    response.raise_for_status()
    data = response.json().get("flowSegmentData", {})
    current = float(data.get("currentSpeed", 0))
    free = float(data.get("freeFlowSpeed", 1))
    level, score = congestion_level(current, free)
    return {"id":"provider-nearby","name":data.get("roadName") or "Nearby road segment",
            "lat":lat,"lon":lon,"speed_kmh":current,"free_flow_kmh":free,
            "length_km":float(data.get("confidence", 0.5)) * 1.0,
            "vehicles":None,"incident":None,"congestion_level":level,
            "congestion_score":score,"delay_min":None}

def get_traffic(lat=None, lon=None):
    lat = float(lat if lat is not None else DEFAULT_CENTER["lat"])
    lon = float(lon if lon is not None else DEFAULT_CENTER["lon"])
    if TRAFFIC_MODE == "tomtom" and TOMTOM_API_KEY:
        try:
            segment = tomtom_traffic(lat, lon)
            return {"source":"TomTom Traffic Flow API", "is_live":True,
                    "updated_at":int(time.time()), "center":{"lat":lat,"lon":lon},
                    "segments":[segment]}
        except (requests.RequestException, ValueError, KeyError) as exc:
            # Explicitly label fallback; never silently claim live data.
            result = demo_traffic()
            result["fallback_reason"] = f"Live provider unavailable: {type(exc).__name__}"
            return result
    return demo_traffic()

# Relative route alternatives for the self-contained prototype. Replace this adapter
# with an authorized routing provider for turn-by-turn production navigation.
ROUTES = [
    {"id":"A","name":"Market Road → Central Ring","distance_km":7.4,"base_min":24,
     "segment_ids":["market-road","central-ring"],"risk":0.25},
    {"id":"B","name":"South Link → East Avenue","distance_km":8.1,"base_min":27,
     "segment_ids":["south-link","east-avenue"],"risk":0.10},
    {"id":"C","name":"Airport Connector → East Avenue","distance_km":9.2,"base_min":29,
     "segment_ids":["airport-road","east-avenue"],"risk":0.08},
]
VEHICLE_FACTORS = {"car":1.0,"freight_truck":1.18,"two_wheeler":0.88,"bus":1.12}

def score_routes(vehicle: str, priority: str, traffic: dict) -> list[dict]:
    by_id = {s["id"]:s for s in traffic["segments"]}
    factor = VEHICLE_FACTORS.get(vehicle, 1.0)
    results = []
    for route in ROUTES:
        congestion_penalty = sum((by_id.get(sid, {}).get("congestion_score", 0) / 100) * 7
                                 for sid in route["segment_ids"])
        mode_penalty = route["risk"] * (5 if vehicle == "freight_truck" else 2)
        estimated = round((route["base_min"] + congestion_penalty + mode_penalty) * factor, 1)
        fuel_penalty = route["distance_km"] * (1.35 if vehicle == "freight_truck" else 1.0)
        if priority == "fuel":
            score = estimated * 0.35 + fuel_penalty * 0.65
        elif priority == "balanced":
            score = estimated * 0.7 + route["distance_km"] * 0.3
        else:
            score = estimated
        results.append({**route, "vehicle":vehicle, "estimated_minutes":estimated,
                        "optimization_score":round(score,2),
                        "reason":"Avoids severe congestion" if congestion_penalty > 5 else "Relatively steady corridor"})
    return sorted(results, key=lambda r:r["optimization_score"])

def signal_recommendations(traffic: dict) -> list[dict]:
    recommendations = []
    for s in traffic["segments"]:
        score = s["congestion_score"]
        green = max(20, min(75, round(25 + score * 0.45)))
        recommendations.append({"intersection":s["name"], "suggested_green_seconds":green,
          "congestion_level":s["congestion_level"],
          "safety_constraints":["Keep pedestrian crossing phase and clearance time unchanged",
             "Preserve minimum red/amber and intergreen intervals",
             "Emergency vehicle pre-emption overrides optimization"],
          "control_mode":"SIMULATION_ONLY"})
    return recommendations

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/health")
def health():
    return jsonify({"status":"ok","service":"FlowPilot API",
                    "traffic_mode":TRAFFIC_MODE,
                    "provider_configured":bool(TOMTOM_API_KEY)})

@app.get("/api/traffic")
def traffic():
    try:
        return jsonify(get_traffic(request.args.get("lat"), request.args.get("lon")))
    except (TypeError, ValueError):
        return jsonify({"error":"lat and lon must be numeric"}), 400

@app.get("/api/route")
def route():
    vehicle = request.args.get("vehicle","car")
    priority = request.args.get("priority","time")
    if vehicle not in VEHICLE_FACTORS:
        return jsonify({"error":f"vehicle must be one of {list(VEHICLE_FACTORS)}"}), 400
    if priority not in {"time","balanced","fuel"}:
        return jsonify({"error":"priority must be time, balanced, or fuel"}), 400
    traffic_data = get_traffic()
    routes = score_routes(vehicle, priority, traffic_data)
    return jsonify({"source":traffic_data["source"],"is_live":traffic_data["is_live"],
                    "recommended":routes[0],"alternatives":routes[1:]})

@app.get("/api/signals")
def signals():
    data = get_traffic()
    return jsonify({"source":data["source"],"is_live":data["is_live"],
                    "mode":"SIMULATION_ONLY","recommendations":signal_recommendations(data)})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT","5000")), debug=True)
