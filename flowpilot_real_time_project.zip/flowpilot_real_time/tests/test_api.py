import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ["TRAFFIC_MODE"] = "demo"
import app as flowpilot

def client():
    flowpilot.app.config["TESTING"] = True
    return flowpilot.app.test_client()

def test_health():
    r = client().get("/api/health")
    assert r.status_code == 200
    assert r.json["status"] == "ok"

def test_demo_traffic_is_not_live():
    r = client().get("/api/traffic")
    assert r.status_code == 200
    assert r.json["is_live"] is False
    assert len(r.json["segments"]) >= 3

def test_route_returns_recommendation():
    r = client().get("/api/route?vehicle=freight_truck&priority=time")
    assert r.status_code == 200
    assert r.json["recommended"]["vehicle"] == "freight_truck"

def test_invalid_vehicle_rejected():
    assert client().get("/api/route?vehicle=spaceship").status_code == 400

def test_signals_are_simulation_only():
    r = client().get("/api/signals")
    assert r.status_code == 200
    assert r.json["mode"] == "SIMULATION_ONLY"
    assert all(x["control_mode"] == "SIMULATION_ONLY" for x in r.json["recommendations"])
