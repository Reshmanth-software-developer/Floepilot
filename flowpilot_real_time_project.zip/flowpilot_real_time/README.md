# FlowPilot — Smart Traffic & Micro-Transit Optimizer

A runnable Flask student-project starter for congestion monitoring, route ranking and **simulation-only** adaptive signal recommendations.

## Architecture

```text
Browser dashboard (HTML/CSS/JS)
        | fetch /api/*
        v
Flask REST API
  |-- /api/traffic  -> demo feed or TomTom Traffic Flow adapter
  |-- /api/route    -> vehicle-aware route scoring
  |-- /api/signals  -> safe, simulation-only timing suggestions
  `-- /api/health   -> service/config status
```

## Run locally

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows; on macOS/Linux use: cp .env.example .env
python app.py
```

Open http://127.0.0.1:5000. The default `TRAFFIC_MODE=demo` is intentionally simulated.

## API examples

- `GET /api/health`
- `GET /api/traffic?lat=17.385&lon=78.4867`
- `GET /api/route?vehicle=freight_truck&priority=time`
- `GET /api/signals`

Vehicle values: `car`, `freight_truck`, `two_wheeler`, `bus`. Priority values: `time`, `balanced`, `fuel`.

## Live traffic provider adapter

The included optional adapter uses **TomTom Traffic Flow Segment Data API v4**. Create a key in the TomTom developer portal, then set `TRAFFIC_MODE=tomtom` and `TOMTOM_API_KEY=...` in your local `.env` (never commit `.env`). The API request is made server-side; the key is not exposed to the browser. A valid provider response is labelled `is_live: true`. If the provider call fails, the API falls back to demo data and labels it `is_live: false` with a fallback reason.

Provider coverage, quotas, free-tier availability and pricing vary by account, region and current TomTom plan. Check the current TomTom developer portal/pricing before a deployment; this project does not assume a fixed quota or price. The current adapter samples one road segment near a coordinate, not an entire citywide feed. Production deployment should query a grid of road points responsibly, cache responses, handle quota limits and map-match actual route geometry.

## Routing provider plan

The route alternatives in this starter are **illustrative corridors**, not turn-by-turn navigation. For a real route engine, integrate a licensed provider (e.g. TomTom Routing API or Google Routes API) or self-host an OpenStreetMap-based engine such as OSRM/Valhalla. Public community demo endpoints are not guaranteed production services and may impose usage policies. Compare commercial plan pricing, coverage, truck restrictions, traffic-aware ETA support, attribution and rate limits before choosing.

## Signal safety

`/api/signals` returns suggestions only. It does not connect to roadside controllers. Any real adaptive control needs city/road authority approval, controller-specific integration, traffic engineering validation, pedestrian clearance phases, minimum green/red/amber and intergreen constraints, emergency-vehicle priority, fail-safe fallback plans, cybersecurity review and audit logging. Do not connect this prototype directly to live signals.

## Tests

```bash
pytest -q
```

## Current limitations / next engineering steps

1. Add geocoding and user-selected origin/destination coordinates.
2. Replace sample corridors with route-provider polylines and traffic-aware ETAs.
3. Sample multiple TomTom flow points along route corridors; add caching and provider error telemetry.
4. Add persistent incident reports and websocket/SSE updates.
5. Validate route restrictions for vehicle height, weight, hazardous cargo and bus lanes.
6. Calibrate signal splits with SUMO simulation and measured queue/arrival data.
7. Deploy behind HTTPS with authentication, rate limiting, logging and secret management.

## SIH-ready project summary

**Problem:** commuters and freight drivers lose time at localized bottlenecks and poorly coordinated junctions.

**Solution:** FlowPilot combines traffic-feed ingestion, hotspot scoring, vehicle-aware route ranking and adaptive signal decision support. It aims to reduce travel delay, idling and fuel use while improving corridor reliability.

**Evaluation metrics:** mean travel time, 95th-percentile delay, queue length, average speed, reroute benefit, fuel/emissions proxy, bus schedule adherence and fairness across road users. Compare a baseline against optimized scenarios using the same demand and network conditions. Report measured results, not assumed percentage improvements.
